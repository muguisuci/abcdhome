import axios from "axios";
import { co } from "@/utils";
/**
 * @description 获取歌手分类
 * @param {Object} data 请求参数
 * @param {Number} data.limit 返回数量 默认为30
 * @param {Number} data.offset 偏移数量 用于分页 , 如 : 如 :( 页数 -1)*30, 其中 30 为 limit 的值 , 默认为 0
* @param {Number}  data.type    类别{-1:全部，1:男歌手，2:女歌手，3:乐队}
* @param {Number}  data.area    地域
 * @returns {Promise}
 */
// 获取歌手列表
// axios.post返回值promise实例
export const getArtisList =(data)=>co(axios.post(`/artist/list?timestamp=${Date.now()}`,data))



/**
 * @description 搜索关键词可以搜索音乐 / 专辑 / 歌手 / 歌单 / 用户 
 * @param {Object} params 请求参数
 * @param {Number}  params.type  搜索类型{1:单曲,10:专辑,100:歌手,1000:歌单,1002:用户,1004:MV,1006: 歌词,1009:电台,1014: 视频,1018:综合,2000:声音}
 * @param {String}  params.keywords 关键词 必写
 * @param {Number} params.limit 返回数量 , 默认为 30
 * @param {Number} params.offset 偏移数量   用于分页,如:( 页数 -1)*30,其中30为limit的值,默认为0
 * @returns {Promise}
 */

// 搜索
export const cloudsearch =(params) => co(axios.get("/cloudsearch", { params }))




/**
 * 
 * @param {Object} data  调用此接口 , 轮播图
 * @returns 
 */


export const getBanner  =(params) => co(axios.get("/banner", { params }))



/**
 * 
 * @param {Object} data  调用此接口 , 轮播图
 * @returns 
 */

export const getHomepage  =(params) => co(axios.post("/homepage/dragon/ball", { params }))


// 获取每日推荐歌单
export const getPersonalized  =(params) => co(axios.get(`/personalized?timestamp=${Date.now()}`, { params }))

cloudsearch().then(function(res){
    console.log(res);
})

export const getHomePageData = () => co(axios.post("/homepage/block/page"));

export const getHomepageDragonBall = () =>
  co(axios.get("/homepage/dragon/ball"));
 






