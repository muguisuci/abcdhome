<template>
  <div id="app">
    <router-view></router-view>
    <Footer class=" bg-white"></Footer>
  </div>
</template>

<script>

export default {
  name: 'App',
  components: {
    
  }
}
</script>

<style>
*{margin: 0;padding: 0;}
#app {
  position: relative;
  height: 200vw;
  overflow-x: hidden;
}



.router-link-active {
    color:red;
}

</style>
