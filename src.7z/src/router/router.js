import Top from "@/views/top"
import Main from "@/views/main"
import Follow from "@/views/follow"
import Myse from "@/views/myse"
import Community from "@/views/community"
// import Footer from "@/components/Footer"
export default [
    {
        path:'/',
        redirect:'/main'
    },
    {
        path:'/main',
        name:'main',
        component: Main,
    },
    {
        path:'/follow',
        name:'follow',
        component: Follow,
    },
    {
        path:'/myse',
        name:'myse',
        component: Myse,
    },
    {
        path:'/community',
        name:'community',
        component: Community,
    },
    {
        path:'/top',
        name:'top',
        component: Top,
    },
    
]