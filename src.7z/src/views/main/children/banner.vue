<template>
  <div class="swiper-container w-[95vw] h-[40vw] m-[auto] rounded-[3vw] text-center bg-red-100">
        <div class="swiper-wrapper">
            <div class="swiper-slide w-[100%] h-[100%]" v-for="item in bannerArr" :key="item.encodeId" >
                <img :src="item.imageUrl" class="w-[100%] h-[100%]">
                <!-- <img :src="item.imageUrl" alt=""> -->
            </div>
        </div>
        <!-- 如果需要分页器 -->
        <div class="swiper-pagination"></div>
    </div>
</template>

<script>
import Swiper from "swiper"
import "swiper/css/swiper.min.css"
import { getBanner } from "@/service"
export default {
    data(){
        return {
            bannerArr:[]
        }
    },
    async created(){
        const [err,res] = await getBanner()
        if (err) return console.log(err)
        // console.log('轮播图数据',res.data.banners);
        this.bannerArr = res.data.banners
    },
    updated(){
        new Swiper ('.swiper-container', {
            // direction: 'vertical', // 垂直切换选项
            loop: true, // 循环模式选项
            
            // 如果需要分页器
            pagination: {
            el: '.swiper-pagination',
            },
            
            // 如果需要前进后退按钮
            navigation: {
            nextEl: '.swiper-button-next',
            prevEl: '.swiper-button-prev',
            },
            
            // 如果需要滚动条
            scrollbar: {
            el: '.swiper-scrollbar',
            },
        }) 
    }
}
</script>

<style>

</style>