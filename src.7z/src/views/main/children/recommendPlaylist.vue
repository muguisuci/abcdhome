<template>
   <Card :title="resource.uiElement.subTitle.title"  class="w-[90vw] ml-[5vw] mt-[2vw]">
    <Scroll>
      <div
        class="flex"
        :style="{ width: `${this.resource.creatives.length * 33}vw` }">
        <div v-for="creative in this.resource.creatives" :key="creative.id" class=" mr-[3vw] relative">
          <Icon icon="ph:play-fill" color="white" class="absolute bottom-[8vw] right-[1vw] text-[4vw]"/>
          <img
            class="w-[30vw] h-[30vw] rounded-[8px] overflow-hidden"
            :src="creative.uiElement.image.imageUrl"
            alt=""
          />
          <div class="text-[2.5vw] w-[30vw]" >{{ creative.uiElement.mainTitle.title }}</div>
        </div>
      </div>
    </Scroll>
  </Card>
</template>

<script>
import Card from './card.vue';
import Scroll from "@/components/Scroll";
export default {
    components: { Card, Scroll },
    props: {
        resource: {
        type: Object,
        required: true,
        },
    },
    created() {
        console.log(this.resource.creatives);
    },
}
</script>

<style>

</style>