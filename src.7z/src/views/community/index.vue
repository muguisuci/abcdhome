<template>
  <div>
    <span>社区页面</span>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>