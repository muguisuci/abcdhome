<template>
  <div>
    <span>排行榜</span>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>