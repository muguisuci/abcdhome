<template>
  <div>
    <span>关注的</span>
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>