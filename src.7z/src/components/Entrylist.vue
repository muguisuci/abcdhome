<template>
   <div class="horizontal-container">
      <div class="scroll-wrapper" ref="scroll">
        <div class="scroll-content">
          <div class="scroll-item text-[2vw] w-[17vw] h-[17vw] " v-for="item in emojis" :key="item.ides">
            <img :src="item.iconUrl"  class="red-image w-[10vw] h-[10vw] ml-[3vw]">
            <span class="text-center text-[2vw]">{{item.name}}</span>
          </div>
        </div>
      </div>
    </div>
</template>

<script>
import BScroll from '@better-scroll/core'
import { getHomepageDragonBall } from "@/service"
export default {
    data () {
      return {
        emojis: []
      }
    },
    mounted() {
      this.init()
    },
    beforeDestroy() {
      this.bs.destroy()
    },
    methods: {
      init() {
        this.bs = new BScroll(this.$refs.scroll, {
          scrollX: true,
          probeType: 3, // listening scroll event
        
        })
      }
    },
    async created(){
        const [err,res] = await getHomepageDragonBall({})
        if (err) return console.log(err)
        console.log('图标数据',res.data.data);
        this.emojis = res.data.data
    },
}
</script>

<style scoped>
    .scroll-wrapper{
  position :relative;
  width :90vw;
  margin: auto;
  white-space: nowrap;
  border-radius: 5px;
  overflow: hidden;
}
  
  .scroll-content{
    display: inline-block;
    width: 210vw;
  }
  .scroll-item{
    height:10vw;
    line-height:10vw;
    font-size:24px;
    display:inline-block;
    text-align:center;
    margin-left: 2vw;
    
  }


  .red-image {

    filter: url("data:image/svg+xml;utf8,<svg xmlns=%27http://www.w3.org/2000/svg%27><filter id=%27colorize%27><feColorMatrix type=%27matrix%27 values=%271 0 0 0 0.698 0 0 0 0 0 0 0 0 0 0 0 0 0 1 0%27/></filter></svg>#colorize");
  }
</style>